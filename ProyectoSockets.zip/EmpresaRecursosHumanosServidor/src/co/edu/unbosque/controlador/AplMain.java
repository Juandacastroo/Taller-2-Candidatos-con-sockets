package co.edu.unbosque.controlador;

/**
 * Siguiendo los estándares de ORACLE esta clase se destina únicamente a la
 * ejecución del programa
 * 
 * @author Juan David Castro García
 * @author Ariadna Sophia Cabrera Carrera
 */

public class AplMain {
	
	 /**
     * Este es el metodo principal su funcion es ejecutar el programa
     * 
     * @param args
     */
	public static void main(String[] args) {
		
		Controller control= new Controller();
		
	}

}
